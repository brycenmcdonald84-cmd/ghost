package dev.ghost;

import dev.ghost.gui.ClickGui;
import dev.ghost.modules.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class GhostClient implements ClientModInitializer {
    public static final List<Module> MODULES = new ArrayList<>();
    private static final Map<Module, KeyBinding> KEYS = new LinkedHashMap<>();
    private static final KeyBinding.Category CATEGORY =
        KeyBinding.Category.create(Identifier.of("ghost", "main"));

    @Override
    public void onInitializeClient() {
        MODULES.add(new KillAura());
        MODULES.add(new TriggerBot());
        MODULES.add(new Sprint());
        MODULES.add(new Speed());
        MODULES.add(new Flight());
        MODULES.add(new Bhop());
        MODULES.add(new Step());
        MODULES.add(new NoFall());
        MODULES.add(new AutoRespawn());
        MODULES.add(new AntiAFK());
        MODULES.add(new Fullbright());
        MODULES.add(new ESP());
        MODULES.add(new Hud());

        Config.load();

        KeyBinding guiKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.ghost.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));
        for (Module m : MODULES) {
            KEYS.put(m, KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ghost." + m.name.toLowerCase(), InputUtil.Type.KEYSYM, m.defaultKey, CATEGORY)));
        }

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGui());
            }
            for (Map.Entry<Module, KeyBinding> e : KEYS.entrySet()) {
                while (e.getValue().wasPressed()) e.getKey().toggle();
            }
            if (client.player == null || client.world == null) return;
            for (Module m : MODULES) if (m.isEnabled()) m.onTick();
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> Config.save());

        HudElementRegistry.attachElementAfter(VanillaHudElements.MISC_OVERLAYS,
            Identifier.of("ghost", "hud"), (ctx, tickCounter) -> Hud.INSTANCE.render(ctx));
    }
}
