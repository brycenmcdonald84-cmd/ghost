package dev.ghost;

import dev.ghost.settings.*;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final Category category;
    public final int defaultKey;
    public final List<Setting> settings = new ArrayList<>();
    public boolean visible = true;        // shown in the HUD module list
    public boolean persistEnabled = false; // remember on/off across restarts
    private boolean enabled;

    protected Module(String name, Category category, int defaultKey) {
        this.name = name;
        this.category = category;
        this.defaultKey = defaultKey;
    }

    public boolean isEnabled() { return enabled; }
    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean v) {
        if (v == enabled) return;
        enabled = v;
        if (v) onEnable(); else onDisable();
    }
    public void setEnabledSilently(boolean v) { enabled = v; }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}

    protected BoolSetting bool(String n, boolean def) { var s = new BoolSetting(n, def); settings.add(s); return s; }
    protected NumSetting num(String n, double def, double min, double max, double step) {
        var s = new NumSetting(n, def, min, max, step); settings.add(s); return s;
    }
    protected ModeSetting mode(String n, String... modes) { var s = new ModeSetting(n, modes); settings.add(s); return s; }

    protected boolean moving() {
        var o = mc.options;
        return o.forwardKey.isPressed() || o.backKey.isPressed() || o.leftKey.isPressed() || o.rightKey.isPressed();
    }
}
