# Ghost Client (Fabric, MC 1.21.11)

## Get the jar (no setup: GitHub builds it)
1. Create a new GitHub repo, upload everything in this folder (keep `.github/`).
2. Open the Actions tab > "build" > the finished run > download the `ghost-client` artifact.
3. Unzip it. Use `ghost-1.0.0.jar` (NOT the `-sources` jar).

## Or build locally
JDK 21 + Gradle 9.2+, then run `gradle build`. Jar: `build/libs/ghost-1.0.0.jar`.

## Modrinth App instance
1. Create an instance: Minecraft 1.21.11, loader Fabric.
2. Instance > Content > Add content > search "Fabric API" and install it.
3. Instance > Content > Add from file > pick `ghost-1.0.0.jar`.
   (Or drop it into the instance's `mods` folder via Open folder.)
4. Launch. Keybinds are under Options > Controls > Key Binds > Ghost Client.

Default keys: R Sprint | B Fullbright | G Flight | V Speed | N NoFall | K KillAura
