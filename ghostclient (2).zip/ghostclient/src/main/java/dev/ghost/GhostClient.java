package dev.ghost;

import dev.ghost.modules.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class GhostClient implements ClientModInitializer {
    public static final List<Module> MODULES = new ArrayList<>();
    private static final Map<Module, KeyBinding> KEYS = new LinkedHashMap<>();
    private static final KeyBinding.Category CATEGORY =
        KeyBinding.Category.create(Identifier.of("ghost", "main"));

    @Override
    public void onInitializeClient() {
        MODULES.add(new Sprint());
        MODULES.add(new Fullbright());
        MODULES.add(new Flight());
        MODULES.add(new Speed());
        MODULES.add(new NoFall());
        MODULES.add(new KillAura());

        for (Module m : MODULES) {
            KEYS.put(m, KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.ghost." + m.name.toLowerCase(), InputUtil.Type.KEYSYM, m.defaultKey, CATEGORY)));
        }

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            for (Map.Entry<Module, KeyBinding> e : KEYS.entrySet()) {
                while (e.getValue().wasPressed()) e.getKey().toggle();
            }
            if (client.player == null || client.world == null) return;
            for (Module m : MODULES) if (m.isEnabled()) m.onTick();
        });

        HudElementRegistry.attachElementAfter(VanillaHudElements.MISC_OVERLAYS,
            Identifier.of("ghost", "module_list"), (ctx, tickCounter) -> {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.options.hudHidden) return;
                int y = 4;
                for (Module m : MODULES) {
                    if (!m.isEnabled()) continue;
                    int w = mc.textRenderer.getWidth(m.name);
                    ctx.drawTextWithShadow(mc.textRenderer, m.name, ctx.getScaledWindowWidth() - w - 4, y, 0xFF55FF55);
                    y += 10;
                }
            });
    }
}
