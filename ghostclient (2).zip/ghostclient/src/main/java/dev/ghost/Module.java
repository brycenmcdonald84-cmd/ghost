package dev.ghost;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();
    public final String name;
    public final int defaultKey;
    private boolean enabled;

    protected Module(String name, int defaultKey) {
        this.name = name;
        this.defaultKey = defaultKey;
    }

    public boolean isEnabled() { return enabled; }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    /** Called every client tick while enabled and in a world. */
    public void onTick() {}
}
