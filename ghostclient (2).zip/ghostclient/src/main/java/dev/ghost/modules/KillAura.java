package dev.ghost.modules;

import dev.ghost.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class KillAura extends Module {
    private static final double RANGE = 4.0;

    public KillAura() { super("KillAura", GLFW.GLFW_KEY_K); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p.getAttackCooldownProgress(0.5f) < 1.0f) return;

        Entity best = null;
        double bestDist = RANGE * RANGE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || e instanceof ArmorStandEntity) continue;
            double d = p.squaredDistanceTo(e);
            if (d < bestDist) { bestDist = d; best = e; }
        }
        if (best == null) return;

        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
    }
}
