package dev.ghost.modules;

import dev.ghost.Module;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class Speed extends Module {
    public Speed() { super("Speed", GLFW.GLFW_KEY_V); }

    @Override
    public void onTick() {
        var p = mc.player;
        var o = mc.options;
        boolean moving = o.forwardKey.isPressed() || o.backKey.isPressed()
                      || o.leftKey.isPressed() || o.rightKey.isPressed();
        if (!moving || !p.isOnGround() || p.isSneaking() || p.isTouchingWater()) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x * 1.35, v.y, v.z * 1.35);
    }
}
