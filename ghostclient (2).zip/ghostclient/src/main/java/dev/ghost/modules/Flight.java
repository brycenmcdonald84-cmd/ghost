package dev.ghost.modules;

import dev.ghost.Module;
import org.lwjgl.glfw.GLFW;

public class Flight extends Module {
    public Flight() { super("Flight", GLFW.GLFW_KEY_G); }

    @Override
    public void onTick() {
        var a = mc.player.getAbilities();
        a.allowFlying = true;
        a.setFlySpeed(0.08f);
    }

    @Override
    protected void onDisable() {
        var p = mc.player;
        if (p == null) return;
        var a = p.getAbilities();
        a.setFlySpeed(0.05f);
        if (!p.isCreative() && !p.isSpectator()) {
            a.allowFlying = false;
            a.flying = false;
        }
    }
}
