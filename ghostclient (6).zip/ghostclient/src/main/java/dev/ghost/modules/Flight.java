package dev.ghost.modules;

import dev.ghost.*;
import dev.ghost.Module;
import dev.ghost.settings.*;
import org.lwjgl.glfw.GLFW;

public class Flight extends Module {
    private final NumSetting speed = num("Speed", 0.6, 0.1, 3.0, 0.05);

    public Flight() { super("Flight", Category.MOVEMENT, GLFW.GLFW_KEY_G); }

    @Override
    public void onTick() {
        var p = mc.player;
        var o = mc.options;
        double yaw = Math.toRadians(p.getYaw());
        double f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        double s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        double x = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double z = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.sqrt(x * x + z * z);
        if (len > 1.0) { x /= len; z /= len; }
        double y = o.jumpKey.isPressed() ? speed.value : (o.sneakKey.isPressed() ? -speed.value : 0);
        p.setVelocity(x * speed.value, y, z * speed.value);
        p.fallDistance = 0;
    }
}
