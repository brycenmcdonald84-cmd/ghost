package dev.ghost.modules;

import dev.ghost.*;
import dev.ghost.Module;
import dev.ghost.settings.*;
import net.minecraft.entity.Entity;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class KillAura extends Module {
    private final NumSetting range = num("Range", 4.0, 3.0, 6.0, 0.1);
    private final NumSetting charge = num("Charge", 1.0, 0.5, 1.0, 0.05);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Mobs", true);
    private final BoolSetting animals = bool("Animals", false);

    public KillAura() { super("KillAura", Category.COMBAT, GLFW.GLFW_KEY_K); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p.getAttackCooldownProgress(0.5f) < charge.f()) return;
        Entity best = null;
        double bestDist = range.value * range.value;
        for (Entity e : mc.world.getEntities()) {
            if (!Targets.valid(e, players.value, mobs.value, animals.value)) continue;
            double d = p.squaredDistanceTo(e);
            if (d < bestDist) { bestDist = d; best = e; }
        }
        if (best == null) return;
        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
    }
}
