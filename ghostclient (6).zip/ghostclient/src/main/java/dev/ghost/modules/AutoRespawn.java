package dev.ghost.modules;

import dev.ghost.*;
import dev.ghost.Module;
import org.lwjgl.glfw.GLFW;

public class AutoRespawn extends Module {
    public AutoRespawn() { super("AutoRespawn", Category.PLAYER, GLFW.GLFW_KEY_UNKNOWN); }

    @Override
    public void onTick() {
        if (mc.player.isDead()) mc.player.requestRespawn();
    }
}
