package dev.ghost.modules;

import dev.ghost.*;
import dev.ghost.Module;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.lwjgl.glfw.GLFW;

public class NoFall extends Module {
    public NoFall() { super("NoFall", Category.PLAYER, GLFW.GLFW_KEY_N); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p.fallDistance > 2.0f) {
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision));
        }
    }
}
