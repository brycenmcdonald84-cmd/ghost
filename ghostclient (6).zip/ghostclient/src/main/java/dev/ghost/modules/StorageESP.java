package dev.ghost.modules;

import dev.ghost.*;
import dev.ghost.Module;
import dev.ghost.settings.*;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Draws a box on every loaded storage block, through walls (2D overlay, see Overlay.java). */
public class StorageESP extends Module {
    public static StorageESP INSTANCE;
    public static volatile List<ChunkScanner.Found> found = List.of();

    public final NumSetting range = num("Range", 96, 16, 256, 8);
    private final BoolSetting chests = bool("Chests", true);
    private final BoolSetting barrels = bool("Barrels", true);
    private final BoolSetting shulkers = bool("Shulkers", true);
    private final BoolSetting ender = bool("EnderChests", true);
    private final BoolSetting others = bool("Others", true);
    public final BoolSetting labels = bool("Distance", true);
    private int timer = 10;

    public StorageESP() {
        super("StorageESP", Category.WORLD, GLFW.GLFW_KEY_UNKNOWN);
        INSTANCE = this;
    }

    @Override protected void onEnable() { timer = 10; }
    @Override protected void onDisable() { found = List.of(); }

    @Override
    public void onTick() {
        if (++timer < 10) return;
        timer = 0;
        var p = mc.player;
        int chunkRadius = (int) Math.ceil(range.value / 16.0) + 1;
        double r2 = range.value * range.value;
        List<ChunkScanner.Found> out = new ArrayList<>();
        for (ChunkScanner.Found f : ChunkScanner.scan(chunkRadius)) {
            if (!wanted(f.type())) continue;
            if (p.squaredDistanceTo(f.pos().getX() + 0.5, f.pos().getY() + 0.5, f.pos().getZ() + 0.5) > r2) continue;
            out.add(f);
        }
        found = out;
    }

    private boolean wanted(StorageType t) {
        return switch (t) {
            case CHEST, TRAPPED -> chests.value;
            case BARREL -> barrels.value;
            case SHULKER -> shulkers.value;
            case ENDER -> ender.value;
            default -> others.value;
        };
    }
}
