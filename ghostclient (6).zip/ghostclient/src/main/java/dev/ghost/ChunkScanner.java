package dev.ghost;

import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;

/** Reads block entities out of the chunks the client has loaded (nothing is sent to the server). */
public final class ChunkScanner {
    private ChunkScanner() {}

    public record Found(BlockPos pos, StorageType type) {}

    public static List<Found> scan(int chunkRadius) {
        MinecraftClient mc = MinecraftClient.getInstance();
        List<Found> out = new ArrayList<>();
        if (mc.player == null || mc.world == null) return out;

        int pcx = mc.player.getBlockPos().getX() >> 4;
        int pcz = mc.player.getBlockPos().getZ() >> 4;
        for (int cx = pcx - chunkRadius; cx <= pcx + chunkRadius; cx++) {
            for (int cz = pcz - chunkRadius; cz <= pcz + chunkRadius; cz++) {
                WorldChunk chunk = mc.world.getChunk(cx, cz);
                if (chunk == null) continue;
                for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
                    StorageType t = classify(be);
                    if (t != null) out.add(new Found(be.getPos(), t));
                }
            }
        }
        return out;
    }

    private static StorageType classify(BlockEntity be) {
        if (be instanceof TrappedChestBlockEntity) return StorageType.TRAPPED;
        if (be instanceof ChestBlockEntity) return StorageType.CHEST;
        if (be instanceof BarrelBlockEntity) return StorageType.BARREL;
        if (be instanceof ShulkerBoxBlockEntity) return StorageType.SHULKER;
        if (be instanceof EnderChestBlockEntity) return StorageType.ENDER;
        if (be instanceof HopperBlockEntity) return StorageType.HOPPER;
        if (be instanceof AbstractFurnaceBlockEntity) return StorageType.FURNACE;
        if (be instanceof DispenserBlockEntity) return StorageType.DISPENSER;
        if (be instanceof BedBlockEntity) return StorageType.BED;
        if (be instanceof BeaconBlockEntity) return StorageType.BEACON;
        return null;
    }
}
