package dev.ghost;

public enum StorageType {
    CHEST("Chest", 1.0, 0xFFFFAA00),
    TRAPPED("Trapped Chest", 1.0, 0xFFFF5555),
    BARREL("Barrel", 1.0, 0xFFC08040),
    SHULKER("Shulker", 3.0, 0xFFAA55FF),
    ENDER("Ender Chest", 0.5, 0xFF55FFFF),
    HOPPER("Hopper", 0.5, 0xFF9999AA),
    FURNACE("Furnace", 0.5, 0xFFDD7744),
    DISPENSER("Dispenser", 1.0, 0xFFBBBBBB),
    BED("Bed", 1.0, 0xFFFFFFFF),
    BEACON("Beacon", 6.0, 0xFF55FFFF);

    public final String label;
    public final double weight;
    public final int color;

    StorageType(String label, double weight, int color) {
        this.label = label; this.weight = weight; this.color = color;
    }

    /** Types that almost never generate naturally (villages, mineshafts etc. don't have them). */
    public boolean playerSign() {
        return this == TRAPPED || this == SHULKER || this == ENDER
            || this == HOPPER || this == DISPENSER || this == BEACON;
    }
}
