package dev.ghost;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

public final class Projector {
    private Projector() {}

    public record Result(int x, int y, double depth, double pxPerBlock, boolean onScreen) {}

    /** Projects a world position to GUI-scaled screen coordinates. */
    public static Result project(Vec3d p, int sw, int sh, boolean clamp) {
        MinecraftClient mc = MinecraftClient.getInstance();
        var pl = mc.player;
        if (pl == null) return null;

        Vec3d cam = pl.getEyePos();
        double yaw = Math.toRadians(pl.getYaw()), pitch = Math.toRadians(pl.getPitch());
        double cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);

        double fx = -sy * cp, fy = -sp, fz = cy * cp;      // forward
        double rx = -cy, rz = -sy;                         // right
        double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy; // up

        double dx = p.x - cam.x, dy = p.y - cam.y, dz = p.z - cam.z;
        double xc = dx * rx + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        double zc = dx * fx + dy * fy + dz * fz;

        double fov = Math.toRadians(mc.options.getFov().getValue());
        double scale = (sh / 2.0) / Math.tan(fov / 2.0);
        double m = 12;

        if (zc > 0.05) {
            double sx = sw / 2.0 + xc / zc * scale;
            double syy = sh / 2.0 - yc / zc * scale;
            if (sx >= m && sx <= sw - m && syy >= m && syy <= sh - m) {
                return new Result((int) sx, (int) syy, zc, scale / zc, true);
            }
        }
        if (!clamp) return null;

        double dxs = xc, dys = -yc;
        if (Math.abs(dxs) < 1e-6 && Math.abs(dys) < 1e-6) dxs = 1;
        double tx = Math.abs(dxs) < 1e-6 ? Double.MAX_VALUE : (sw / 2.0 - m) / Math.abs(dxs);
        double ty = Math.abs(dys) < 1e-6 ? Double.MAX_VALUE : (sh / 2.0 - m) / Math.abs(dys);
        double t = Math.min(tx, ty);
        return new Result((int) (sw / 2.0 + dxs * t), (int) (sh / 2.0 + dys * t), zc, 0, false);
    }

    public static void outline(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.fill(x1, y1, x2, y1 + 1, color);
        ctx.fill(x1, y2 - 1, x2, y2, color);
        ctx.fill(x1, y1, x1 + 1, y2, color);
        ctx.fill(x2 - 1, y1, x2, y2, color);
    }

    public static void line(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        int steps = Math.min(250, Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1)) / 2);
        for (int i = 0; i <= steps; i++) {
            double t = steps == 0 ? 0 : (double) i / steps;
            int x = (int) (x1 + (x2 - x1) * t), y = (int) (y1 + (y2 - y1) * t);
            ctx.fill(x, y, x + 1, y + 1, color);
        }
    }
}
