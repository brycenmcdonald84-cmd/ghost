package dev.ghost;

import com.google.gson.*;
import dev.ghost.settings.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    private Config() {}
    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("ghost.json"); }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : GhostClient.MODULES) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                JsonObject s = new JsonObject();
                for (Setting st : m.settings) s.add(st.name, st.save());
                o.add("settings", s);
                root.add(m.name, o);
            }
            Files.writeString(file(), new GsonBuilder().setPrettyPrinting().create().toJson(root));
        } catch (Exception ignored) {}
    }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            JsonObject root = JsonParser.parseString(Files.readString(file())).getAsJsonObject();
            for (Module m : GhostClient.MODULES) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (m.persistEnabled && o.has("enabled")) m.setEnabledSilently(o.get("enabled").getAsBoolean());
                if (!o.has("settings")) continue;
                JsonObject s = o.getAsJsonObject("settings");
                for (Setting st : m.settings) {
                    try { if (s.has(st.name)) st.load(s.get(st.name)); } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {}
    }
}
