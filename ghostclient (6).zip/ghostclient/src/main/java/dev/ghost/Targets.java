package dev.ghost;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;

public final class Targets {
    private Targets() {}

    public static boolean valid(Entity e, boolean players, boolean mobs, boolean animals) {
        if (!(e instanceof LivingEntity le) || e == MinecraftClient.getInstance().player
                || !le.isAlive() || e instanceof ArmorStandEntity) return false;
        if (e instanceof PlayerEntity) return players;
        if (e instanceof Monster) return mobs;
        if (e instanceof AnimalEntity) return animals;
        return false;
    }
}
