package dev.ghost.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class ModeSetting extends Setting {
    public final String[] modes;
    public int index;

    public ModeSetting(String name, String... modes) { super(name); this.modes = modes; }

    public String value() { return modes[index]; }
    public void cycle(int dir) { index = Math.floorMod(index + dir, modes.length); }

    @Override public JsonElement save() { return new JsonPrimitive(value()); }
    @Override public void load(JsonElement e) {
        String s = e.getAsString();
        for (int i = 0; i < modes.length; i++) if (modes[i].equals(s)) index = i;
    }
}
