package dev.ghost;

import dev.ghost.modules.BaseFinder;
import dev.ghost.modules.Hud;
import dev.ghost.modules.StorageESP;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public final class Overlay {
    private Overlay() {}
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final String[] ARROWS = {"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"};

    public static void render(DrawContext ctx) {
        if (mc.player == null || mc.world == null) return;
        TextRenderer tr = mc.textRenderer;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();

        StorageESP esp = StorageESP.INSTANCE;
        if (esp != null && esp.isEnabled()) {
            int drawn = 0;
            for (Scanner.Found f : StorageESP.found) {
                if (drawn >= 300) break;
                float[] p = project(f.pos().getX() + 0.5, f.pos().getY() + 0.5, f.pos().getZ() + 0.5, w, h);
                if (p == null) continue;
                drawn++;
                int half = (int) Math.max(2, Math.min(40, p[2]));
                outline(ctx, (int) p[0] - half, (int) p[1] - half, (int) p[0] + half, (int) p[1] + half, f.type().color);
                if (esp.labels.value && half >= 3) {
                    String s = (int) p[3] + "m";
                    ctx.drawTextWithShadow(tr, s, (int) p[0] - tr.getWidth(s) / 2, (int) p[1] + half + 2, f.type().color);
                }
            }
        }

        BaseFinder bf = BaseFinder.INSTANCE;
        if (bf != null && bf.isEnabled()) {
            List<BaseFinder.Cluster> list = BaseFinder.clusters;
            int max = (int) bf.show.value;
            int y = h / 2 - 30;
            ctx.drawTextWithShadow(tr, "Bases (" + list.size() + ")", 4, y, Hud.accent(0));
            y += 11;
            for (int i = 0; i < Math.min(max, list.size()); i++) {
                BaseFinder.Cluster c = list.get(i);
                double dx = c.x() - mc.player.getX(), dz = c.z() - mc.player.getZ();
                double targetYaw = Math.toDegrees(Math.atan2(-dx, dz));
                double rel = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
                String arrow = ARROWS[Math.floorMod((int) Math.round(rel / 45.0), 8)];
                String line = String.format("#%d %s %dm  %d %d  S%.0f", i + 1, arrow, (int) Math.hypot(dx, dz),
                    (int) c.x(), (int) c.z(), c.score());
                ctx.drawTextWithShadow(tr, line, 4, y, c.sign() ? 0xFFFFFF55 : 0xFFFFFFFF);
                ctx.drawTextWithShadow(tr, c.summary(), 4, y + 10, 0xFF999999);
                y += 22;
            }

            if (bf.markers.value) {
                for (int i = 0; i < Math.min(max, list.size()); i++) {
                    BaseFinder.Cluster c = list.get(i);
                    float[] p = project(c.x(), c.y() + 1, c.z(), w, h);
                    if (p == null) continue;
                    int col = Hud.accent(i * 3);
                    outline(ctx, (int) p[0] - 5, (int) p[1] - 5, (int) p[0] + 5, (int) p[1] + 5, col);
                    String s = "Base " + (int) p[3] + "m";
                    ctx.drawTextWithShadow(tr, s, (int) p[0] - tr.getWidth(s) / 2, (int) p[1] - 16, col);
                }
            }
        }
    }

    private static void outline(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.fill(x1, y1, x2, y1 + 1, color);
        ctx.fill(x1, y2 - 1, x2, y2, color);
        ctx.fill(x1, y1, x1 + 1, y2, color);
        ctx.fill(x2 - 1, y1, x2, y2, color);
    }

    /** Returns {screenX, screenY, halfBlockInPixels, distance} or null if the point is off screen / behind you. */
    private static float[] project(double x, double y, double z, int w, int h) {
        var p = mc.player;
        Vec3d cam = p.getCameraPosVec(1.0f);
        double dx = x - cam.x, dy = y - cam.y, dz = z - cam.z;

        double yaw = Math.toRadians(p.getYaw()), pitch = Math.toRadians(p.getPitch());
        double cp = Math.cos(pitch), sp = Math.sin(pitch), sinY = Math.sin(yaw), cosY = Math.cos(yaw);
        double fx = -sinY * cp, fy = -sp, fz = cosY * cp;          // forward
        double rx = -cosY, ry = 0, rz = -sinY;                      // right
        double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx; // up

        double camX = dx * rx + dy * ry + dz * rz;
        double camY = dx * ux + dy * uy + dz * uz;
        double camZ = dx * fx + dy * fy + dz * fz;
        if (camZ < 0.05) return null;

        double t = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        double aspect = (double) w / h;
        double nx = camX / (camZ * t * aspect), ny = camY / (camZ * t);
        if (Math.abs(nx) > 1.15 || Math.abs(ny) > 1.15) return null;

        float sx = (float) (w / 2.0 * (1 + nx));
        float sy = (float) (h / 2.0 * (1 - ny));
        float halfBlock = (float) (0.5 / (camZ * t) * h / 2.0);
        return new float[]{sx, sy, halfBlock, (float) Math.sqrt(dx * dx + dy * dy + dz * dz)};
    }
}
