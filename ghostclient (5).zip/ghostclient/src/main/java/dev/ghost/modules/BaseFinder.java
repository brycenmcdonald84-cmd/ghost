package dev.ghost.modules;

import dev.ghost.*;
import dev.ghost.Module;
import dev.ghost.settings.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.*;

/**
 * Groups nearby storage blocks into clusters and scores them. A cluster with hoppers, shulkers,
 * trapped/ender chests etc. (things that don't generate naturally) is flagged as a likely base.
 */
public class BaseFinder extends Module {
    public static BaseFinder INSTANCE;
    public static volatile List<Cluster> clusters = List.of();
    private static final Set<String> announced = new HashSet<>();

    public final NumSetting chunks = num("Chunks", 12, 4, 32, 1);
    private final NumSetting clusterSize = num("ClusterSize", 48, 16, 128, 8);
    private final NumSetting minScore = num("MinScore", 8, 3, 60, 1);
    public final NumSetting show = num("Show", 5, 1, 8, 1);
    private final BoolSetting playerSigns = bool("PlayerSigns", true);
    private final BoolSetting alerts = bool("Alerts", true);
    public final BoolSetting markers = bool("Markers", true);
    private int timer = 40;

    public record Cluster(double x, double y, double z, double score, boolean sign, Map<StorageType, Integer> counts) {
        public String summary() {
            StringBuilder sb = new StringBuilder();
            int shown = 0;
            for (var e : counts.entrySet()) {
                if (shown++ >= 4) break;
                if (sb.length() > 0) sb.append(", ");
                sb.append(e.getValue()).append(' ').append(e.getKey().label);
            }
            return sb.toString();
        }
    }

    public BaseFinder() {
        super("BaseFinder", Category.WORLD, GLFW.GLFW_KEY_UNKNOWN);
        INSTANCE = this;
    }

    @Override protected void onEnable() { timer = 40; }
    @Override protected void onDisable() { clusters = List.of(); }

    @Override
    public void onTick() {
        if (++timer < 40) return;
        timer = 0;

        int vd = mc.options.getViewDistance().getValue();
        List<Scanner.Found> all = Scanner.scan(Math.min((int) chunks.value, vd));
        int size = (int) clusterSize.value;

        Map<Long, List<Scanner.Found>> cells = new HashMap<>();
        for (Scanner.Found f : all) {
            int cx = Math.floorDiv(f.pos().getX(), size), cz = Math.floorDiv(f.pos().getZ(), size);
            cells.computeIfAbsent(key(cx, cz), k -> new ArrayList<>()).add(f);
        }

        List<Cluster> out = new ArrayList<>();
        Set<Long> seen = new HashSet<>();
        for (Long start : cells.keySet()) {
            if (!seen.add(start)) continue;
            Deque<Long> queue = new ArrayDeque<>();
            queue.add(start);
            List<Scanner.Found> group = new ArrayList<>();
            while (!queue.isEmpty()) {
                long c = queue.poll();
                group.addAll(cells.get(c));
                int cx = (int) (c >> 32), cz = (int) c;
                for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                    long n = key(cx + dx, cz + dz);
                    if (cells.containsKey(n) && seen.add(n)) queue.add(n);
                }
            }
            Cluster cl = build(group);
            int storage = cl.counts().getOrDefault(StorageType.CHEST, 0) + cl.counts().getOrDefault(StorageType.BARREL, 0);
            boolean looksPlayerMade = cl.sign() || storage >= 12;
            if (cl.score() >= minScore.value && (!playerSigns.value || looksPlayerMade)) out.add(cl);
        }

        out.sort((a, b) -> Double.compare(b.score(), a.score()));
        clusters = out;

        if (alerts.value) for (Cluster c : out) announce(c);
    }

    private static long key(int cx, int cz) { return ((long) cx << 32) | (cz & 0xFFFFFFFFL); }

    private static Cluster build(List<Scanner.Found> group) {
        double sx = 0, sy = 0, sz = 0, score = 0;
        boolean sign = false;
        Map<StorageType, Integer> counts = new EnumMap<>(StorageType.class);
        for (Scanner.Found f : group) {
            sx += f.pos().getX(); sy += f.pos().getY(); sz += f.pos().getZ();
            score += f.type().weight;
            sign |= f.type().playerSign();
            counts.merge(f.type(), 1, Integer::sum);
        }
        int n = group.size();
        return new Cluster(sx / n, sy / n, sz / n, score, sign, counts);
    }

    private void announce(Cluster c) {
        String dim = mc.world.getRegistryKey().getValue().toString();
        String id = dim + ":" + Math.floorDiv((int) c.x(), 64) + "," + Math.floorDiv((int) c.z(), 64);
        if (!announced.add(id)) return;
        String line = String.format("%s  X %d  Y %d  Z %d  score %.0f  (%s)",
            dim, (int) c.x(), (int) c.y(), (int) c.z(), c.score(), c.summary());
        mc.player.sendMessage(Text.literal("[Ghost] Possible base: " + line), false);
        try {
            Files.writeString(FabricLoader.getInstance().getConfigDir().resolve("ghost-bases.txt"),
                line + System.lineSeparator(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception ignored) {}
    }
}
